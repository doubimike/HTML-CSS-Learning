# wechat-deleted-friends
查看被删的微信好友

原理就是新建群组,如果加不进来就是被删好友了(不要在群组里讲话,别人是看不见的)

用的是微信网页版的接口

查询结果可能会引起一些心理上的不适,请小心使用..(逃

还有些小问题:

结果好像有疏漏一小部分,原因不明..

最终会遗留下一个只有自己的群组,需要手工删一下

没试过被拉黑的情况

Mac OS用法:
启动Terminal

`$ python wdf.py`

按指示做即可

## 其他语言实现

[Go 版](https://github.com/miraclesu/wechat-deleted-friends)

[Node.js 版](https://github.com/chemdemo/wechat-helper)

[Chrome 插件](https://github.com/liaohuqiu/wechat-helper)

